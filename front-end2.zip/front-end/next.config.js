module.exports = {
  env: {
    PUBLIC_URL: "",
    // API_URL:"http://api.daelmac.com"
    API_URL:"http://127.0.0.1:5003"
  }
};
