import Link from "next/link";
import { Container, Row, Col } from "react-bootstrap";
import { LayoutTwo } from "../components/Layout";
import { BreadcrumbOne } from "../components/Breadcrumb";
import { connect } from "react-redux";
import { useToasts } from "react-toast-notifications";
import { setCurrentUser } from "../redux/actions/userActions";
import Router from "next/router";
import { CustomerLogin, CreateCustomer,Createcrud } from "../api/userApi";
import { useEffect, useState } from "react";
import { EmailRegX } from "../core/utils";
import { getallcrud } from "../api/productApi";



const LoginRegister = ({ setCurrentUser, userDetails }) => {
  useEffect(() => {
    if (userDetails && userDetails.role === "customer") Router.push("/");
    
  });
  const [crud,setCrud]=useState([])
  useEffect(async () => {
    const all_crud = await getallcrud();
    if (all_crud) setCrud(all_crud);
  }, []);
  const { addToast } = useToasts();
  const [user, setUSer] = useState({
    email: "",
    password: "",
  });
  const [errors, setErrors] = useState({
    emailErrMsg: "",
    passwordErrMsg: "",
    serverErrMsg: "",
  });

  const [newcrud, setNewcrud] = useState({
    firstName: "",
    lastName: "",
    
  });
 
  const [newUserErrors, setNewUSerErrors] = useState({
    firstNameErrMsg: "",
    lastNameErrMsg: "",
    emailErrMsgErrMsg: "",
    passwordErrMsg: "",
    confirmPassword: "",
    serverErrMsg: "",
  });
  const intNewUser = () => {
    let userBlank = {
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      confirmPassword: "",
    };
    setNewUSer(userBlank);
  };
  
  const handleRegistercrudChange = async (event) => {
   
    const { name, value } = event.target;
    setNewcrud({ ...newcrud, [name]: value });
  };
  const handleSubmit = async (event) => {
    event.preventDefault();
    if (validate()) {
      const response = await CustomerLogin(user);
      if (response) {
        if (response.status === "success" && response.role === "customer") {
          setCurrentUser(response, addToast);
          Router.push("/");
        } else {
          setErrors({ ...errors, serverErrMsg: response.status_message });
        }
      } else {
        setErrors({
          ...errors,
          serverErrMsg: "something went wrong,please try again",
        });
      }
    }
  };
  const onRegistercrud = async (event) => {
      event.preventDefault();
 
      console.log(newcrud);
      const response = await Createcrud(newcrud);
      console.log("response"+response)
      if (response) {
        if (response.status === "success") {
          addToast("Registered Successfully.Please log in.", {
            appearance: "success",
            autoDismiss: true,
          });
         
          // Router.push("/login-register");
        } else {
          setNewUSerErrors({
            ...newUserErrors,
            serverErrMsg: response.status_message,
          });
        }
      } else {
        setNewUSerErrors({
          ...newUserErrors,
          serverErrMsg: "something went wrong,please try again",
        });
      }

  };




  return (
    <LayoutTwo aboutOverlay={false}>
      {/* breadcrumb */}
      {/* <BreadcrumbOne
        pageTitle="Customer Login"
        backgroundImage="/assets/images/backgrounds/breadcrumb-bg-2.jpg"
      >
        <ul className="breadcrumb__list">
          <li>
            <Link href="/" as={process.env.PUBLIC_URL + "/"}>
              <a>Home</a>
            </Link>
          </li>

          <li>Customer Login</li>
        </ul>
      </BreadcrumbOne> */}
      <div className="login-area space-mt--80 space-mb--r80">
        <Container>
          <Row>
          
            <Col lg={6}>
              <div className="lezada-form login-form--register">
                <form>
                  <Row>
                    <Col lg={12}>
                      <div className="section-title--login text-center space-mb--50">
                        <h2 className="space-mb--20">Register</h2>
                        <p>If you don’t have an account, register now!</p>
                      </div>
                    </Col>
                    <Col lg={6} className="space-mb--30">
                      <label htmlFor="regFirstName">
                        First Name <span className="required">*</span>{" "}
                      </label>
                      <input
                        type="text"
                        id="regFirstName"
                        name="firstName"
                        placeholder="First Name"
                        value={newcrud.firstName}
                        required
                        onChange={handleRegistercrudChange}
                      />
                      <span className="error-text">
                        {newUserErrors.firstNameErrMsg}
                      </span>
                    </Col>
                    <Col lg={6} className="space-mb--30">
                      <label htmlFor="regLastName">
                        Last Name <span className="required">*</span>{" "}
                      </label>
                      <input
                        type="text"
                        id="regLastName"
                        name="lastName"
                        placeholder="Last Name"
                        value={newcrud.lastName}
                        required
                        onChange={handleRegistercrudChange}
                      />
                      <span className="error-text">
                        {newUserErrors.lastNameErrMsg}
                      </span>
                    </Col>
                  
                    <span className="error-text ml-3 mb-3">
                      {newUserErrors.serverErrMsg}
                    </span>
                    <Col lg={12} className="text-center">
                      <button
                        className="lezada-button lezada-button--medium"
                        onClick={onRegistercrud}
                      >
                        register
                      </button>
                    </Col>
                  </Row>
                </form>
              </div>
            </Col>
            {
              crud.map((e)=>
              {
                return (
                  <>
                  <h1>
                    Prodct Id-
                   { e.fname }
                  </h1>
                  </>
                )
              })
            }
          </Row>
        </Container>
      </div>
    </LayoutTwo>
  );
};
const mapDispatchToProps = (dispatch) => {
  return {
    setCurrentUser: (user, addToast) => {
      dispatch(setCurrentUser(user, addToast));
    },
  };
};
const mapStateToProps = (state) => {
  return {
    userDetails: state.currentUserData,
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(LoginRegister);
