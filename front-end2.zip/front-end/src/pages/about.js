import { useState } from "react";
import Link from "next/link";
import { Container, Row, Col } from "react-bootstrap";
import { IoMdAdd } from "react-icons/io";
import ModalVideo from "react-modal-video";
import { LayoutTwo } from "../components/Layout";
import { BreadcrumbOne } from "../components/Breadcrumb";
// import card
import {
  MDBCard,
  MDBCardBody,
  MDBCardTitle,
  MDBCardText,
  MDBCardImage,
  MDBBtn
} from 'mdb-react-ui-kit';



const About = () => {
  const [modalStatus, isOpen] = useState(false);

  return (
    <LayoutTwo aboutOverlay={false}>
      {/* breadcrumb */}
      <BreadcrumbOne
        pageTitle="About"
        backgroundImage="/assets/images/banners/About Us1.jpg"
      >
        <ul className="breadcrumb__list">
          <li>
            <Link href="/" 
            as={process.env.PUBLIC_URL + "/"}
            >
              Home
            </Link>
          </li>

          <li>About</li>
        </ul>
      </BreadcrumbOne>
      {/* about content */}
      <div className="about-content space-mt--r130 space-mb--r130">
        <div className="section-title-container space-mb--40">
          <Container>
            <Row>
              <Col lg={8} className="ml-auto mr-auto" >
                {/* section title */}
                <div className="about-title-container text-center" data-aos="fade-up">
                  <p className="dark-title space-mb--35"  >
                    A report about your rapport
                  </p>
                  <h2 className="title space-mb--15">Our Story</h2>
                  <p className="title-text">
                  Throttle as an organization started in 2017. Initially we started as a practice facility. 
                  We have turf wickets, astro turf practise facility, gym, ice bath, physiotherapy, open wicket facility. 
                  Now we've got elevated our scope of enterprise to cricket and sports merchandise.
                   As a brand we started out in 2021.
                    We have sponsored players who have gone on to represent India and represent IPL, in conjunction with that many Ranji Trophy and TNPL.
                  </p>
                </div>
              </Col>
            </Row>










            <br/>
            <br/>
            <div className="about-title-container text-center" data-aos="fade-up">
            <h2 className="title space-mb--15">Players Sponsered by Throttle</h2>
            </div>
            <br/>
            <Row>

          
            <Col lg={3} className="ml-auto mr-auto" >
             <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Alexander R.jpeg'
      
      position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Alexander R</MDBCardTitle>
        <MDBCardText>
        Tamilnadu, TNPL
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard> 
          
            
    </Col>
    <Col lg={3} className="ml-auto mr-auto" >
          
    <MDBCard>
      <MDBCardImage
      height={315}
      src='/assets/images/Sponsered players/Boopathi Vaishav Kumar.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Boopathi Vaishav Kumar</MDBCardTitle>
        <MDBCardText>
        India Emerging, Tamilnadu, TNPL
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>  
            
    </Col>
    <Col lg={3} className="ml-auto mr-auto" >
        
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Ganesh S.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Ganesh S</MDBCardTitle>
        <MDBCardText>
         Tamilnadu, TNPL
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>
            
    </Col>
    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Gurjapneet Singh.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Gurjapneet Singh</MDBCardTitle>
        <MDBCardText>
         Tamilnadu, TNPL
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>
          
            
    </Col>
    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/K C Cariappa.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>K C Cariappa</MDBCardTitle>
        <MDBCardText>
        IPL , Ranji Karnataka
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>
               
    </Col>

    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Yazh Arunmozhi.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Yazh Arunmozhi</MDBCardTitle>
        <MDBCardText>
        IPL , Ranji Karnataka
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>
               
    </Col> 
    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/K H Gopinath.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Card title</MDBCardTitle>
        <MDBCardText>
         Tamilnadu, TNPL
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>
               
    </Col>
    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Kiran Akash.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Card title</MDBCardTitle>
        <MDBCardText>
         Tamilnadu, TNPL
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>
               
    </Col>
    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Mohan Prasath.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Mohan Prasath</MDBCardTitle>
        <MDBCardText>
         Tamilnadu, TNPL
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>
               
    </Col>
    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/R Rohit.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>R Rohit</MDBCardTitle>
        <MDBCardText>
         Tamilnadu, TNPL
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>
               
    </Col>
    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Rooban Raj.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Rooban Raj</MDBCardTitle>
        <MDBCardText>
         Tamilnadu, TNPL
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>
               
    </Col>
    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Sanjay Yadav.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Sanjay Yadav</MDBCardTitle>
        <MDBCardText>
        IPL MUMBAI INDIANS, Tamilnadu, TNPL
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>
               
    </Col>
    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Siddarth S.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Siddarth S</MDBCardTitle>
        <MDBCardText>
         Tamilnadu, TNPL
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>
               
    </Col>
   
    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Trilok Nag.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Trilok Nag</MDBCardTitle>
        <MDBCardText>
         Tamilnadu, TNPL
        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>
               
    </Col>

    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Tushar Raheja.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Tushar Raheja</MDBCardTitle>
        <MDBCardText>
         Tamilnadu, TNPL
        </MDBCardText>
        {/* <MDBBtn href='#'>Button</MDBBtn> */}
      </MDBCardBody>
    </MDBCard>
               
    </Col>
    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Easwaran K.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Easwaran K</MDBCardTitle>
        <MDBCardText>
         Tamilnadu, TNPL
        </MDBCardText>
        {/* <MDBBtn href='#'>Button</MDBBtn> */}
      </MDBCardBody>
    </MDBCard>
               
    </Col>
    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Rajamani Prabhu.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Rajamani Prabhu</MDBCardTitle>
        <MDBCardText>
        Trainer of Rajasthan Royals and owner of R-Accelerate Fitness
        </MDBCardText>
        {/* <MDBBtn href='#'>Button</MDBBtn> */}
      </MDBCardBody>
    </MDBCard>
               
    </Col>
    <Col lg={3} className="ml-auto mr-auto" >
    <MDBCard>
      <MDBCardImage  height={315} src='/assets/images/Sponsered players/Throttle’s team.jpeg' position='top' alt='...' />
      <MDBCardBody>
        <MDBCardTitle>Throttle’s team</MDBCardTitle>
        <MDBCardText>
        Venkatesh Iyer (india) Sudeep Tyagi (india, IPL) Lalit Mohan (Ranji Andhra) Mohammed Azarudeen (IPL, Ranji Kerala) Puneet Datey (Ranji Madhya Pradesh), Girinath Reddy (Ranji Andhra)

        </MDBCardText>
      
      </MDBCardBody>
    </MDBCard>
               
    </Col>

 

            </Row>





          <br/>
            <br/>
            <div className="about-title-container text-center" data-aos="fade-up">
            <h2 className="title space-mb--15">Players who practice in throttle</h2>
            </div>
            <br/>





            <Row>

          
<Col lg={3} className="ml-auto mr-auto" >
 <MDBCard>
<MDBCardImage  height={315} src='/assets/images/Sponsered players/Alexander R.jpeg'

position='top' alt='...' />
<MDBCardBody>
<MDBCardTitle>Alexander R</MDBCardTitle>
<MDBCardText>
Tamilnadu, TNPL
</MDBCardText>

</MDBCardBody>
</MDBCard> 


</Col>
</Row>
          </Container>
        </div>









        









        {/* about video content */}
        <div className="about-video-content space-mb--r100">
          <Container>
            <Row>
              <Col lg={10} className="ml-auto mr-auto">
                {/*=======  about video area  =======*/}
                <div
                data-aos="fade-left"
                  className="about-video-bg space-mb--60"
                  style={{
                    backgroundImage: `url(${
                      process.env.PUBLIC_URL +
                      "/assets/images/about-us/grand_sports_video_background.jpg"
                    })`,
                  }}
                >
                  {/* <p className="video-text video-text-left">
                    <Link
                      href="/shop/all-products"
                      as={process.env.PUBLIC_URL + "/shop/all-products"}
                    >
                      <a>LEZADA STORE</a>
                    </Link>
                  </p> */}

                  <div className="about-video-content__text-icon d-flex flex-column h-100 justify-content-center" >
                    <div className="play-icon text-center space-mb--40" >
                      <ModalVideo
                        channel="youtube"
                        isOpen={modalStatus}
                        videoId="aX3DtR-n4yE"
                        
                        onClose={() => isOpen(false)}
                      />
                      <button onClick={() => isOpen(true)}>
                        <img
                          src={
                            process.env.PUBLIC_URL +
                            "/assets/images/icon/icon-play-100x100.png"
                          }
                          className="img-fluid"
                          alt=""
                        />
                      </button>
                    </div>
                    {/* <h1>OUR STORY</h1> */}
                  </div>
                  {/* <p className="video-text video-text-right">
                    <Link
                      href="/about"
                      as={process.env.PUBLIC_URL + "/about"}
                    >
                      <a>OUR STORY</a>
                    </Link>
                  </p> */}
                </div>
              </Col>
            </Row>
            <Row>
              <Col lg={10} className="ml-auto mr-auto">
                <Row data-aos="fade-up">
                  <Col md={6}>
                    <div className="about-widget space-mb--35">
                      <h2 className="widget-title space-mb--25">ADDRESS</h2>
                      <p className="widget-content">
                      78/55, River View Avenue, Ambedkar Nagar, Manapakkam, Chennai, Tamil Nadu 600125
                      </p>
                    </div>
                    <div className="about-widget space-mb--35">
                      <h2 className="widget-title space-mb--25">PHONE</h2>
                      <p className="widget-content">   <a href="tel:9444925100">09444925100</a> </p>
                    </div>
                    <div className="about-widget">
                      <h2 className="widget-title space-mb--25">EMAIL</h2>
                      <p className="widget-content">
                    <a href="mailto:throttlesportxone@gmail.com">throttlesportxone@gmail.com</a>{" "}
                      </p>
                    </div>
                  </Col>
                  <Col md={6}>
                    <div className="about-page-text">
                      <p className="space-mb--35">
                        Our Store houses top Indian and International Cricket
                        equipment brands like SS, SG, Tyka to name a few. From
                        English willow bats to economical bats, Grand Sports
                        stocks them all. Just click the "Visit Our online Store" button
                        below to grab top class products.
                      </p>
                      <Link
                        href="/shop/all-products"
                        as={process.env.PUBLIC_URL + "/shop/all-products"}
                      >
                        <a className="lezada-button lezada-button--medium lezada-button--icon--left">
                          <IoMdAdd /> Visit Our online Store
                        </a>
                      </Link>
                    </div>
                  </Col>
                </Row>
              </Col>
            </Row>
          </Container>
        </div>
      </div>
    </LayoutTwo>
  );
};

export default About;
