const Preloader = () => {
  return <div className="preloader"></div>;
};

export default Preloader;
