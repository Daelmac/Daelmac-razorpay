import ImageCta from "./ImageCta";


export { ImageCta };
