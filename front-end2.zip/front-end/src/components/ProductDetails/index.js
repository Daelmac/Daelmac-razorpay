import ImageGalleryBottomThumb from "./ImageGalleryBottomThumb";
import ProductDescription from "./ProductDescription";
import ProductDescriptionTab from "./ProductDescriptionTab";

export {
  ImageGalleryBottomThumb,
  ProductDescription,
  ProductDescriptionTab
};
