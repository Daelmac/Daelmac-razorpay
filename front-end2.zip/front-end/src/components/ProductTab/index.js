import ProductTab from "./ProductTab";

export { ProductTab};
