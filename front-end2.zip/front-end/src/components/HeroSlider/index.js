import HeroSliderOne from "./HeroSliderOne";

export {
  HeroSliderOne,
};
