import HeaderOne from "./HeaderOne";
import HeaderTwo from "./HeaderTwo";

export {
  HeaderOne,
  HeaderTwo,
};
