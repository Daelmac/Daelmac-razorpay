import Link from "next/link";
const Navigation = () => {
  return (
    <nav className="header-content__navigation space-pr--15 space-pl--15 d-none d-lg-block"
    style={{
      color:'#ffffff'
    }}
    >
      <ul>
        <li>
          <Link
            href="/"
            as={process.env.PUBLIC_URL + "/"}
          >
            
            <a
             style={{
              color:'white'
            }}
            >Home</a>
          </Link>
        </li>
        <li>
          <Link
            href="/shop/all-products"
            as={process.env.PUBLIC_URL + "/shop/all-products"}
          >
            <a
              style={{
                color:'white'
              }}
            >Products</a>
          </Link>
        </li>
        <li>
          <Link
            href="/about"
            as={process.env.PUBLIC_URL + "/about"}
          >
            <a
              style={{
                color:'white'
              }}
            >About Us</a>
          </Link>
        </li>
        <li>
          <Link
            href="/contact"
            as={process.env.PUBLIC_URL + "/contact"}
          >
            <a
            
            style={{
              color:'white'
            }}>Contact Us</a>
          </Link>
        </li>
        <li>
          <Link
            href="/faq"
            as={process.env.PUBLIC_URL + "/faq"}
          >
            <a
              style={{
                color:'white'
              }}
            >F.A.Q</a>
          </Link>
        </li>
      </ul>
    </nav>
  );
};

export default Navigation;
