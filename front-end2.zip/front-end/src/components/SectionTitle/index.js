import SectionTitleOne from "./SectionTitleOne";
import SectionTitleTwo from "./SectionTitleTwo";
export {
  SectionTitleOne,
  SectionTitleTwo,
};
