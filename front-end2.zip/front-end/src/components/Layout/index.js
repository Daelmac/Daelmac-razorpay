import LayoutTwo from "./LayoutTwo";
import AdminLayout from "./AdminLayout";

export {
  LayoutTwo,
  AdminLayout
};
